from django.db import models
from django.urls import reverse


# Create your models here.

class Category(models.Model):
    objects = None
    title=models.CharField(max_length=255)
    slug=models.SlugField(max_length=255, verbose_name='Url', unique=True)

    class Meta:
        verbose_name='Категория',
        verbose_name_plural='Категории',
        ordering=['title']

    def str(self):
        return self.title
    def get_absolute_url(self):
        return reverse('category', kwargs={"slug": self.slug})


class Tag(models.Model):
    title = models.CharField(max_length=255)
    slug=models.SlugField(max_length=255,verbose_name='Url',unique=True)

    def str(self):
        return self.title
    def get_absolute_url(self):
        return reverse('tag', kwargs={"slug": self.slug})
    class Meta:
        verbose_name = 'Тег',
        verbose_name_plural = 'Теги',
        ordering = ['title']

class Post(models.Model):
    title = models.CharField(max_length=255,verbose_name='Заголовок')
    slug = models.SlugField(max_length=255, verbose_name='Url', unique=True)
    author = models.CharField(max_length=100)
    content=models.TextField(blank=True)
    created_at=models.DateTimeField(auto_now_add=True,verbose_name='Опубликовано')
    photo = models.ImageField(upload_to='photos/%Y/%m/%d', blank=True)
    views=models.IntegerField(default=0,verbose_name='Кол-во просмотров')
    category = models.ForeignKey(Category,on_delete=models.PROTECT,related_name='posts',verbose_name='Катгория')
    tags=models.ManyToManyField(Tag,blank=True,related_name='posts')

    def str(self):
        return self.title

    def get_absolute_url(self):
        return reverse('post', kwargs={"slug": self.slug})
    class Meta:
        verbose_name = 'Статья',
        verbose_name_plural = 'Статьи',
        ordering = ['title']
