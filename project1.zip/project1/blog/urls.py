from django.urls import path
from .views import *
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    #path('', index, name='home'),
    path('', Home.as_view(), name='home'),
    path('category/<str:slug>', PostsByCategory.as_view(), name='category'),
    path('post/<str:slug>/', GetPost.as_view(), name='post'),
    path('tag/<str:slug>/', PostsByTag.as_view(), name='tag'),
    path('posts/add-news/', add_news, name='add_news'),
    #path('' , home, name='home'),
    path('numbers/', spisok, name='numbers'),
    path('tablo/', table, name='tablo'),
    path('cascad_tablo/', cascad_table, name='cascad_tablo'),
    path('sacad_tablo2/', sacad_table7, name='sacad_tablo2'),
    path('forms2/', forms8, name='forms2'),
    path('task9/', verstka9, name='task9'),
]


if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
