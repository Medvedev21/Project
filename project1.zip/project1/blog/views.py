from django.shortcuts import render, redirect
from django.http import HttpResponse
from django.views.generic import ListView, DetailView
from .models import Post, Category, Tag
from django.db.models import F
from .forms import PostsForm


class Home(ListView):
    model = Post
    template_name = 'blog/index.html'
    context_object_name = 'posts'
    paginate_by = 2

    def get_context_data(self, *, object_list=None, **kwargs):
        context = super().get_context_data(**kwargs)
        context['title'] = 'Claasic Blog Design'
        return context


def index(request):
    return render(request, 'blog/index.html')


def get_category(request, slug):
    return render(request, 'blog/category.html')


def home(request):
    return render(request, 'blog/home.html')


def spisok(request):
    return render(request, 'blog/number.html')


def table(request):
    return render(request, 'blog/tablo.html')


def cascad_table(request):
    return render(request, 'blog/cascad_tablo.html')


def sacad_table7(request):
    return render(request, 'blog/sacad_tablo2.html')


def forms8(request):
    return render(request, 'blog/forms2.html')


def verstka9(request):
    return render(request, 'blog/task9.html')


def get_post(request, slug):
    return render(request, 'blog/category.html')


class PostsByCategory(ListView):
    template_name = 'blog/index.html'
    context_object_name = 'posts'
    paginate_by = 2
    allow_empty = False

    def get_queryset(self):
        return Post.objects.filter(category__slug=self.kwargs['slug'])

    def get_context_data(self, *, object_lists=None, **kwargs):
        context = super().get_context_data(**kwargs)
        context['title'] = Category.objects.get(slug=self.kwargs['slug'])
        return context


class GetPost(DetailView):
    model = Post
    template_name = 'blog/single.html'
    context_object_name = 'post'

    def get_context_data(self, *, object_list=None, **kwargs):
        context = super().get_context_data(**kwargs)
        self.object.views = F('views') + 1
        self.object.save()
        self.object.refresh_from_db()
        return context


class PostsByTag(ListView):
    pass


class PostsForm:
    pass


def add_news(request):
    if request.method == 'POST':
        form = PostsForm(request.POST)
        if form.is_valid():
            Post.objects.create(**form.cleaned_data)
            return redirect('home')
    else:
        form = PostsForm()
    return render(request, 'blog/add_news.html', {'form': form})
